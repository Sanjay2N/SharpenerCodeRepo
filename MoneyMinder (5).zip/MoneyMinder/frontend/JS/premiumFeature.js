const leaderBoardButton=document.querySelector("#leader-board-button");
const leaderBoardDiv=document.querySelector("#leader-board-div");
const leaderBoardList=document.querySelector("#leader-board-body");


function parseJwt(token) {
    var base64Url = token.split('.')[1];
    var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    var jsonPayload = decodeURIComponent(window.atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));

    return JSON.parse(jsonPayload);
}

const decodedToken=parseJwt(localStorage.getItem("token"));
console.log(decodedToken);

if(decodedToken.isPremiumUser===true){
    document.querySelector("#rzp-button1").classList.add("d-none")
    leaderBoardButton.classList.remove("d-none");

    leaderBoardButton.addEventListener("click",getLeaderBoard);

    async function getLeaderBoard(){
        leaderBoardButton.classList.add("d-none");
        const token=localStorage.getItem("token");
        const response=await axios.get("http://localhost:2000/premium/showleaderboard",{headers:{"Authorization":token}});
        response.data.forEach(expenseDetails=>{
            addToLeaderBoard(expenseDetails);
        })
        leaderBoardDiv.classList.remove("d-none");
        leaderBoardDiv.classList.add("d-block");


    }
}


    function addToLeaderBoard(expenseDetails){
        if(expenseDetails.totalexpense==null){
            return;
        }
        leaderBoardList.innerHTML+=`
                <tr >
                        <td>${expenseDetails.name}</td>
                        <td>${expenseDetails.totalexpense}</td>
                        
                        
                        
                      </tr>`
}
