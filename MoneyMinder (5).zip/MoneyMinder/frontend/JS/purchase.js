
const razorpayButton=document.querySelector("#rzp-button1");
razorpayButton.onclick=async (e)=>{
    try{

    const token=localStorage.getItem("token");
    const response=await axios.get("http://localhost:2000/purchase/premiummemborship",{headers:{"Authorization":token}});
    var options={
        "key":response.data.key_id,
        "order_id":response.data.order.id,
        //function excecuted on success
        "handler":async function(response){
            const response1=await axios.post("http://localhost:2000/purchase/updatetransactionstatus",{
                order_id:options.order_id,
                payment_id:response.razorpay_payment_id,

            },{headers:{"Authorization":token}});

            alert("you have premium account");
            localStorage.setItem("token",response1.data.token);
            window.location.href="../HTML/expense.html";

        }

    };
    const rzp1=new Razorpay(options);
    rzp1.open();
    e.preventDefault();
    rzp1.on('payment.failed',async function(reponse){
        await axios.post("http://localhost:2000/purchase/updatetransactionstatus",{
        order_id:options.order_id,
        success:false,
 
            },{headers:{"Authorization":token}});
        alert("Some thing went wrong");
    })

    }
    catch(error){
        console.log("error  ",error)
    }

}