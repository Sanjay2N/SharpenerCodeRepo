const Sequelize=require('sequelize');
const sequelize=require('../util/databse');
const Comment=sequelize.define('comment',{
    id:{
        type:Sequelize.INTEGER,
        primaryKey:true,
        allowNull:false,
        autoIncrement:true,


    },
    content:{
        type:Sequelize.TEXT,
        allowNull:false,
    },
    
})

module.exports=Comment;