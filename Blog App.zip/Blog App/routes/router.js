const controller=require('../controllers/controller');

const express=require('express');

const router=express.Router();


router.post("/post-blog",controller.postBlog);
router.get("/get-blog",controller.getBlog);

router.post("/post-comment",controller.postComment);







module.exports=router;