const myform=document.querySelector("#myform");
const blogList=document.querySelector(".blogList");




myform.addEventListener("submit",addBlog);
window.addEventListener("DOMContentLoaded",reloadBlog);

function addComment(e){
    e.preventDefault();
    const comment=e.target.comment.value;
    axios.post("http://localhost:2000/post-comment",{comment:comment})
    .then(response=>{
        console.log("response from comment :",response);

    })
}

function reloadBlog(e){
    e.preventDefault();
    axios.get("http://localhost:2000/get-blog")
    .then(response=>{
        response.data.forEach(blog=>{
            showOnDisplay(blog);
        })
    })
}



function addBlog(e){
    e.preventDefault();

    const name=e.target.name.value;
    const author=e.target.author.value;
    const content=e.target.content.value;
    const id=e.target.id.value;

    // console.log(name);
    // console.log("")
    // console.log(author);
    // console.log("")
    // console.log(content)
    myobj={
        id:id,
        name:name,
        author:author,
        content:content,
    }
    
    axios.post("http://localhost:2000/post-blog",myobj)
    .then(response=>{
        showOnDisplay(response.data);
    })
}


function showOnDisplay(response){
    
    var div=document.createElement('div');
    div.className="container blog "+response.id;
    console.log(response.blogName)
    var h2=document.createElement('h2');
    h2.appendChild(document.createTextNode(response.blogName));
    div.appendChild(h2);
    var p=document.createElement('p');
    p.appendChild(document.createTextNode(`author : ${response.author}`))
    div.appendChild(p);
    div.appendChild(document.createElement('hr'));
    var h6=document.createElement('p');
    h6.appendChild(document.createTextNode(response.content));
    div.appendChild(h6);
    // div.appendChild('br');
    const commentheader=document.createElement('h5');
    commentheader.appendChild(document.createTextNode("Comment"))
    div.appendChild(commentheader);
    var commentdiv=document.createElement('div');
    commentdiv.classList=" commenttab form-group";

    const form=document.createElement('form');
    form.classList="comment";

    const comment=document.createElement('input');
    comment.classList="form-control col-10 "+response.id;
    comment.type="text";
    comment.id="comment";
    const send=document.createElement('button');
    send.appendChild(document.createTextNode("send"));
    send.type='submit';
    send.classList="input-group-button btn btn-primary";
    form.appendChild(comment);
    form.appendChild(send);

    commentdiv.appendChild(form);
    div.appendChild(commentdiv)

    div.style.border="#7d34eb 2px solid";
    const commentList=document.createElement('ul');
    commentList.classList="commentList";
    div.style.marginBottom="3px"

    blogList.appendChild(div);
    myform.reset();
    const commentsend=document.querySelector(".comment");

    commentsend.addEventListener("submit",addComment);


}