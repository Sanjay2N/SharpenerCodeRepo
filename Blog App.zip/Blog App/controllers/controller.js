const { connected } = require('process');
const Blog=require('../models/blog');
const Comment=require('../models/comment');


exports.postBlog=(req,res,next)=>{
    const name=req.body.name;
    const author=req.body.author;
    const content=req.body.content;

    // console.log("in post blog page /////////////////////")
    Blog.create({
        blogName:name,
        author:author,
        content:content
    })
    .then(reponse=>{
        console.log(reponse);
        res.json(reponse.dataValues);
    })
}


exports.getBlog=(req,res,next)=>{
    Blog.findAll()
    .then(response=>{
        // console.log("****************************************************************")
        // console.log(response.data);
        res.json(response);
    })
    .catch(err=>{
        res.json({error:err})
    })
}

exports.postComment=(req,res,next)=>{
    console.log("{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}")
    console.log(req.body.content)
    Comment.create({
        content:req.body.content
    }).then(response=>{
        res.json(response);
    })
}