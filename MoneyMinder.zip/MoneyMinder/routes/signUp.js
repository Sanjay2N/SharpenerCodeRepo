const express=require('express');
const router=express.Router();
const signUpController=require("../controllers/signUp");

router.post("/signUp",signUpController.signUpUser);
module.exports=router;