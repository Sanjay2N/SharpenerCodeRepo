const signUpSection=document.querySelector("#signup-body");
const signInSection=document.querySelector("#signin-body");



// nav bar section

const navbar=document.querySelector("#navbar");
const signInPageButton=navbar.querySelector("#signin");
const signUpPageButton=navbar.querySelector("#signup");
console.log(signInPageButton)
signInPageButton.addEventListener('click',(e)=>{
    e.preventDefault();
    hideAndShow(signUpSection,signInSection)
})
signUpPageButton.addEventListener('click',(e)=>{
    e.preventDefault();
    hideAndShow(signInSection,signUpSection)
})

function hideAndShow(block1,block2){
    block1.classList.remove('d-flex');
    block1.classList.add('d-none');
    block2.classList.remove('d-none');
    block2.classList.add('d-flex');
}




// Signup section------------------------------------------------>>>>>>>>>>>

const form=signUpSection.querySelector("#form");
const warnig=signUpSection.querySelector("#warning");
const signInButton=signUpSection.querySelector("#signin");

signInButton.addEventListener('click',(e)=>{
    e.preventDefault();
    hideAndShow(signUpSection,signInSection)
})

form.addEventListener("submit",signUp);


function signUp(e){
    e.preventDefault();
    const name=e.target.name.value;
    const email=e.target.email.value;
    const phoneNUmber=e.target.number.value;
    const password=e.target.password.value;
    const conformPassword=e.target.conformationPassword.value;

    if(password!==conformPassword){
        warnig.innerText="Password not matching !!";
        signUpSection.querySelector("#password").value="";
        signUpSection.querySelector("#conformationPassword").value="";
        return;
    }

    userDetails={
        name:name,
        phoneNumber:phoneNUmber,
        email:email,
        password:password

    };
    let errorItem;
    axios.post("http://localhost:2000/signUp",userDetails)
    .then(response=>{
        if(response.data.error){
            if(response.data.error.errors[0].path==="phoneNumber"){
                signUpSection.querySelector("#number").value="";
                errorItem="Phone Number";
            }
            else if (response.data.error.errors[0].path==="email"){
                signUpSection.querySelector("#email").value="";
                errorItem="Email";
            }
            else {
                signUpSection.querySelector("#password").value="";
                signUpSection.querySelector("#conformationPassword").value="";
                errorItem="Password";
            }
            warnig.innerText=`${errorItem} already exists`;
            return; 
        }
        else{
            e.target.reset()
        }
    })
}


// signIn section


const signInForm=signInSection.querySelector("#signinform");
const SignInWarnig=signInSection.querySelector("#warning");
const signUpButton=signInSection.querySelector("#signin");
console.log("form  : ",signInForm);
console.log("warnign : ",SignInWarnig)

signUpButton.addEventListener('click',(e)=>{
    e.preventDefault();
    hideAndShow(signInSection,signUpSection)
})

signInForm.addEventListener("submit",signIn);

function signIn(e){
    e.preventDefault();
    console.log(e.target)
    const email=e.target.email1.value;
    const password=e.target.password1.value;
    userCredentials={
        email:email,
        password:password,
    };
    let errorItem;
    axios.post("http://localhost:2000/signIn",userCredentials)
    .then(response=>{
        const userDetails=response.data;
        if(userDetails.message!=="success"){
            SignInWarnig.innerText=userDetails.message;
            e.target.reset();
            
            return; 
        }
        else{
            SignInWarnig.innerText=userDetails.message;
            e.target.reset();
        }
    })
}