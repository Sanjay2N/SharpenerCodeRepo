const User=require("../models/user");

exports.signUpUser=(req,res,next)=>{
    
    const name=req.body.name;
    const email=req.body.email;
    const phoneNumber=req.body.phoneNumber;
    const password=req.body.password;
   
    
    User.create({
        name:name,
        email:email,
        phoneNumber:phoneNumber,
        password:password
    })
    .then(response=>{
        res.json(response);
    })
    .catch(err=>{
        res.json({error:err});
    })


}