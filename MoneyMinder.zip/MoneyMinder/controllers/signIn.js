const User=require("../models/user");

exports.signInUser=(req,res,next)=>{
    
    const email=req.body.email;
    const password=req.body.password;
    User.findAll({where:{email:email}})
    .then(response=>{
        console.log(typeof(response))
        if(response.length==0){
            console.log("/////////////////////")
            res.json({message:"User doesn't exists!!"});
        }
        if(response[0].dataValues.password!==password){
            res.json({message:"Password not matching!!"});
        }
        else{
            res.json({message:"success"});
            
        }
        
    })
    .catch(err=>{
        res.json({error:err});
    })

}