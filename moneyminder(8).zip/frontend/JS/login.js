
const signInForm=document.querySelector("#signinform");
const SignInWarnig=document.querySelector("#warning");

signInForm.addEventListener("submit",signIn);

async function signIn(e){
    try{
        e.preventDefault();
        const email=e.target.email1.value;
        const password=e.target.password1.value;
        const data={
            email:email,
            password:password,
        };
        const response=await axios.post("http://localhost:2000/user/login",data);
        if(response && response.status==200){
            console.log(response.data);
            localStorage.setItem("token",response.data.token);
            if(response.data.isPremiumUser===true){
                window.location.href="../HTML/premiumUserExpense.html";
                
            }
            window.location.href="../HTML/expense.html";
            
        }

    
}
catch(error){
    if (error.response && error.response.status === 404) {
        console.log("Authentication failed. User is not found.");
        SignInWarnig.innerText="Authentication failed. User is not found.";
    } else if (error.response && error.response.status === 401) {
        console.log("Authentication failed. User is unauthorized.");
        SignInWarnig.innerText="Authentication failed. User is unauthorized.";
    }else if (error.response && error.response.status === 400) {
        console.log("Authentication failed. User is unauthorized.");
        SignInWarnig.innerText="Some thing is missing";
    }
     else {
        console.error("An error occurred:", error);
    }
}
}
