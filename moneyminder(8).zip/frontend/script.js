const signUpSection=document.querySelector("#signup-body");
const signInSection=document.querySelector("#signin-body");
const signinSignupSection=document.querySelector("#signin-signup-section");
const expenseSection=document.querySelector("#expense-details-section");
let userId;


// nav bar section

const navbar=document.querySelector("#navbar");
const signInPageButton=navbar.querySelector("#signin");
const signUpPageButton=navbar.querySelector("#signup");
console.log(signInPageButton)
signInPageButton.addEventListener('click',(e)=>{
    e.preventDefault();
    hideAndShow(signUpSection,signInSection)
})
signUpPageButton.addEventListener('click',(e)=>{
    e.preventDefault();
    hideAndShow(signInSection,signUpSection)
})

function hideAndShow(block1,block2){
    block1.classList.remove('d-flex');
    block1.classList.add('d-none');
    block2.classList.remove('d-none');
    block2.classList.add('d-flex');
}




// Signup section------------------------------------------------>>>>>>>>>>>

const form=signUpSection.querySelector("#form");
const warnig=signUpSection.querySelector("#warning");
const signInButton=signUpSection.querySelector("#signin");

signInButton.addEventListener('click',(e)=>{

    e.preventDefault();

    hideAndShow(signUpSection,signInSection)
})

form.addEventListener("submit",signUp);


async function signUp(e){
    try{

    e.preventDefault();
    const name=e.target.name.value;
    const email=e.target.email.value;
    const phoneNUmber=e.target.number.value;
    const password=e.target.password.value;
    const conformPassword=e.target.conformationPassword.value;

    if(password!==conformPassword){
        warnig.innerText="Password not matching !!";
        signUpSection.querySelector("#password").value="";
        signUpSection.querySelector("#conformationPassword").value="";
        return;
    }

    userDetails={
        name:name,
        phoneNumber:phoneNUmber,
        email:email,
        password:password

    };
   

    
    const response=await axios.post("http://localhost:2000/user/signUp",userDetails)
    const userCredentials=await axios.post("http://localhost:2000/user/signIn",{email:userDetails.email,password:userDetails.password});
    console.log(userCredentials)
    userId=userCredentials.data.userCredentials.id;
    signinSignupSection.classList.remove('d-block');
        signinSignupSection.classList.add('d-none');
        expenseSection.classList.remove('d-none');
        expenseSection.classList.add('d-block');

    // localStorage.setItem('token', JSON.stringify({name:userDetails.Name,token:userCredentials.userDetails.token}));
    // window.location.href = `user`;     

    }
catch(error){
    if (error.response && error.response.status === 401) {
        e.preventDefault();
        console.log("Authentication failed. User is already exist.");
        warnig.innerText="Authentication failed. User is already exist.";
    } else {
        console.error("An error occurred:", error);
    }
}
}

// signIn section


const signInForm=signInSection.querySelector("#signinform");
const SignInWarnig=signInSection.querySelector("#warning");
const signUpButton=signInSection.querySelector("#signin");
console.log("form  : ",signInForm);
console.log("warnign : ",SignInWarnig)

signUpButton.addEventListener('click',(e)=>{
    e.preventDefault();
    hideAndShow(signInSection,signUpSection)
})

signInForm.addEventListener("submit",signIn);

async function signIn(e){
    try{
    e.preventDefault();
    console.log(e.target)
    const email=e.target.email1.value;
    const password=e.target.password1.value;
    const data={
        email:email,
        password:password,
    };
    const response=await axios.post("http://localhost:2000/signIn",data);
    const userCredentials=response.data;
    console.log(response && response.status==200)
    if(response && response.status==200){
        console.log(userCredentials)
        userId=userCredentials.id;
        signinSignupSection.classList.remove('d-block');
        signinSignupSection.classList.add('d-none');
        expenseSection.classList.remove('d-none');
        expenseSection.classList.add('d-block');
    }
    else{
        console.log("in the else block")
    }
}
catch(error){
    console.log("int the error section")
    if (error.response && error.response.status === 404) {
        console.log("Authentication failed. User is not found.");
        SignInWarnig.innerText="Authentication failed. User is not found.";
    } else if (error.response && error.response.status === 401) {
        console.log("Authentication failed. User is unauthorized.");
        SignInWarnig.innerText="Authentication failed. User is unauthorized.";
    } else {
        console.error("An error occurred:", error);
    }
}
}


// add expenses---------------------------------------------------------------------->

 



