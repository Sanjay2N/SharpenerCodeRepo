const { Sequelize } = require("sequelize");
const Expense=require("../models/expense");
const User=require("../models/user");
const sequelize = require("../util/database");


exports.getLeaderBoard=async(req,res)=>{
    

    try{
        const response=await User.findAll({
            attributes: [ "name","totalexpense"],
            order:[['totalexpense','DESC']],
        });
        
        res.status(200).json(response);
    }
    catch(error){
        res.status(500).json({error:error});
    }

}

