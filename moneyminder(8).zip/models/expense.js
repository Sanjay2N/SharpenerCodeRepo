const sequelize=require("../util/database");
const Sequelize=require("sequelize");

const expense=sequelize.define("expense",{
    id:{
        type:Sequelize.INTEGER,
        allowNull:false,
        primaryKey:true,
        autoIncrement:true,
    },
    date:{
        type:Sequelize.DATEONLY,
    },
    amount:{
        type:Sequelize.INTEGER,
        allowNull:false,

    },
    category:{
        type:Sequelize.STRING,
        allowNull:false,

    },
    description:{
        type:Sequelize.STRING,
    },
    
})


module.exports=expense;