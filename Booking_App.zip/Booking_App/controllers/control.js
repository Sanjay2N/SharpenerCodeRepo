const Appointments=require('../models/appointments');

exports.getAppointments=(req,res,next)=>{
    Appointments.findAll().then(result=>{
        // console.log("?????????????????????????????????????????????????/")
        // console.log("result : ", result[0].dataValues)
        res.json(result);
    }).catch(err=>{
        res.status(500).json({error:err});
    })
    
}

exports.postAppointment=async (req,res,next)=>{
    
   if(req.body.id==-1){
    try{
        if(!req.body.number){
            throw new Error("Phone number required");
        }
    // console.log(req.body)
    const name=req.body.name;
    const email=req.body.email;
    const number=req.body.number;
    // console.log("name",name)
    
    Appointments.create({
        
        name:name,
        email:email,
        phone_number:number,
    }).then(result=>{
        console.log("appointment created")
        // console.log("resulr: ",result)
        res.json(result);
    })
    .catch(err=>{
        res.status(500).json({error:err});
    })
    
}
catch{
    err=>{
        res.status(500).json({error:err});
    }
}
   }
   else{

    const id=req.body.id;
    const name=req.body.name;
    const number=req.body.phone_number;
    const email=req.body.email;
    Appointments.findByPk(id)
    .then(product=>{
        product.name=name;
        product.number=number;
        product.email=email;
        product.save();
        res.json(product);
    })
   
    .catch(err=>{
        res.status(500).json({error:err});
        console.log(err);
    })
   }
}

exports.deleteAppointment=(req,res,next)=>{
    console.log(req.body);
        
        Appointments.findAll({where:{id:req.body.id}}).then(response=>{
            // console.log(response);
            response[0].destroy();
        }).then(result=>{
            // res.redirect("/get-appointment")
            res.status(200);
        })
        .catch(err=>{
            res.status(500).json({error:err});
        })
    
    
}


exports.geteditAppointment=(req,res,next)=>{
    console.log("get edit id : ", req.params.prodId)
    Appointments.findByPk(req.params.prodId).then(response=>{
        // console.log("response  :  ",response.dataValues)
        res.json(response);
    })
    .catch(err=>{
        
        console.log(err);
        res.status(500).json({error:err});
    })
}


