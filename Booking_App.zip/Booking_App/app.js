const path=require('path');
const express=require('express');
const bodyParser=require('body-parser');

const sequelize = require('./util/database');
const Appointments=require('./models/appointments');

const app=express();

const cors=require('cors');

app.use(cors());
app.set('view engine', 'ejs');
app.set('views', 'views');

const routes=require('./routes/mainRouter');
app.use(bodyParser.urlencoded({ extended: true }));

app.use(bodyParser.json({ extended: false }));
app.use(express.static( path.join(__dirname,'public')));


app.use(routes);




sequelize
.sync()
// .sync({force:true})
.then(result=>{
    app.listen(3000);})
.catch(err=>{
    console.log(err)
});