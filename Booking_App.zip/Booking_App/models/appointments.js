const sequelize=require('../util/database');

const Sequelize=require('sequelize');

const Appointment=sequelize.define('appointments',{
    id:{
        type:Sequelize.INTEGER,
        primaryKey:true,
        allowNull:false,
        autoIncrement:true,
    },
    name:{
        type:Sequelize.STRING,
        allowNull:false,
        

    },
    phone_number:{
        type:Sequelize.STRING,
        allowNull:false,
        unique:true,
    },
    email:{
        type:Sequelize.STRING,
        unique:true,

    }

})

module.exports=Appointment;