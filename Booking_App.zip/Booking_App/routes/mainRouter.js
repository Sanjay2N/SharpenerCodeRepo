const path=require('path');

const express=require('express');

const controller=require('../controllers/control');

const router=express.Router();

router.get('/get-appointment',controller.getAppointments);

router.post('/post-appointment',controller.postAppointment);

router.post('/delete-appointment',controller.deleteAppointment);

router.get('/getedit-appointment/:prodId',controller.geteditAppointment);

router.post('/postedit-appointment',controller.postAppointment);

module.exports=router;