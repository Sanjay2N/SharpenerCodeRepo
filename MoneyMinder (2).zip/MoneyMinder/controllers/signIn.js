const User=require("../models/user");
const bcrypt=require('bcrypt');

exports.signInUser=(req,res,next)=>{
    try{

    
    const email=req.body.email;
    const password=req.body.password;
    User.findAll({where:{email:email}})
    .then(response=>{
        console.log(typeof(response))
        if(response.length==0){
            // console.log("/////////////////////")
            res.status(400).json({success:false,message:"User doesn't exists!!"});
        }
        bcrypt.compare(password,response[0].dataValues.password,(err,response)=>{
            if(err){
                res.status(400).json({success:false,message:"Password not matching!!"});
            }
            else{
                res.status(200).json({success:true,message:"success"});
                
            }
        })
    })
    
}
catch{
    
        res.status(500).json({error:err});
    
}

}