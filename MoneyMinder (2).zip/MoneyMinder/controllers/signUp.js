const User=require("../models/user");
const bcrypt=require('bcrypt');

exports.signUpUser=(req,res,next)=>{
    
    try{
    const name=req.body.name;
    const email=req.body.email;
    const phoneNumber=req.body.phoneNumber;
    const password=req.body.password;
    const saltrounds=10;
   bcrypt.hash(password,saltrounds,async(err,hash)=>{
    User.create({
        name:name,
        email:email,
        phoneNumber:phoneNumber,
        password:hash
    })
    .then(response=>{
        res.status(200).json(response);
    })
    
   })

   
    
}
catch{
    res.status(500).json({error:err});
}


}