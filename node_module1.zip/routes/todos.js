"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const router = (0, express_1.Router)();
const todos = [];
router.get("/", (req, res, next) => {
    res.status(200).json({ todos: todos });
});
router.post("/todo", (req, res, next) => {
    console.log(req.body);
    const newTodo = { id: new Date().toISOString(),
        text: req.body.text,
    };
    todos.push(newTodo);
    return res.status(201).json({ message: "successful " });
});
router.post("/delete", (req, res, next) => {
    console.log("size", todos.length);
    for (let i = 0; i < todos.length; i++) {
        console.log((todos[i].id), (req.body.id));
        if ((todos[i].id) === (req.body.id)) {
            todos.splice(i, 1);
            console.log("found");
            return res.status(200).json({ message: "successfull" });
        }
    }
    console.log("not found");
    return res.status(404).json({ message: "unsuccessfull" });
});
router.post("/edit", (req, res, next) => {
    console.log("size", todos.length);
    for (let i = 0; i < todos.length; i++) {
        console.log((todos[i].id), (req.body.id));
        if ((todos[i].id) === (req.body.id)) {
            todos[i].text = req.body.text;
            return res.status(201).json({ message: "successfull" });
        }
    }
    console.log("not found");
    return res.status(404).json({ message: "unsuccessfull" });
});
exports.default = router;
