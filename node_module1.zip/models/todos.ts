export interface Todo{  //named export
    id:string;
    text:string;
}