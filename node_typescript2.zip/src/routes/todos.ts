import {Router} from "express";
const router=Router();

import {Todo} from '../models/todos'; //named import 
import { connected } from "process";

const todos:Todo[]=[];

type requestBody={text:string};
type requestParams={todoId:string};

router.get("/todo",(req,res,next)=>{
    res.status(200).json({todos:todos});
})
router.post("/todo",(req,res,next)=>{
    const body=req.body as requestBody;
    const newTodo:Todo={id:new Date().toISOString(),
    text:body.text,
};
todos.push(newTodo);
return res.status(201).json({message:"successful "})
})


router.delete("/todo/:todoId",(req,res,next)=>{
    const params=req.params as requestParams;
    const todoId=params.todoId;
    const todoIndex=todos.findIndex((todo)=>{
        return todo.id===todoId;
    });
    if(todoIndex>=0){
        todos.splice(todoIndex,1);
        return res.status(201).json({message:"successfull"});
    }
    return res.status(404).json({message:"unsuccessfull"});
})

router.put("/todo/:todoId",(req,res,next)=>{
    const params=req.params as requestParams;
    const todoId=params.todoId;
    const body=req.body as requestBody;

    const todoIndex=todos.findIndex((todo)=>{
        return todo.id===todoId;
        
    });
    if(todoIndex>=0){
        todos[todoIndex].text=body.text;
        return res.status(201).json({message:"successfull"});
    }
    
    return res.status(404).json({message:"unsuccessfull"});
})

export default router;
