const controller=require('../controllers/controller');

const express=require('express');

const router=express.Router();


router.post("/post-blog",controller.postBlog);
router.get("/get-blog",controller.getBlog);

router.post("/post-comment",controller.postComment);

router.get("/get-comments/:blogId",controller.getComment);

router.post("/delete-comment",controller.deleteComment);







module.exports=router;