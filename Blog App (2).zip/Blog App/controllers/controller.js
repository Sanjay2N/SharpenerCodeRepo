const { connected } = require('process');
const Blog=require('../models/blog');
const Comment=require('../models/comment');


exports.postBlog=(req,res,next)=>{
    const name=req.body.name;
    const author=req.body.author;
    const content=req.body.content;

    // console.log("in post blog page /////////////////////")
    Blog.create({
        blogName:name,
        author:author,
        content:content
    })
    .then(reponse=>{
        console.log(reponse);
        res.json(reponse.dataValues);
    })
    .catch(err=>{
        res.json({error:err})
    })
}


exports.getBlog=(req,res,next)=>{
    Blog.findAll()
    .then(response=>{
        // console.log("****************************************************************")
        // console.log(response.data);
        res.json(response);
    })
    .catch(err=>{
        res.json({error:err})
    })
}

exports.postComment=(req,res,next)=>{
    // console.log("{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}")
    // console.log(req.body)
    Comment.create({
        BlogId:req.body.id,
        content:req.body.comment
    })
    .then(response=>{
        res.json(response);
    })
    .catch(err=>{
        res.json({error:err})
    })
    
}

exports.getComment=(req,res,next)=>{
    const blogId=req.params.blogId;
    Comment.findAll({where:{BlogId:blogId}})
    .then(response=>{
        res.json(response);
    })
    .catch(err=>{
        res.json({error:err})
    })
}


exports.deleteComment=(req,res,next)=>{
    const id=req.body.id;
    Comment.findAll({where:{id:id}})
    .then(response=>{
        // console.log("////////////////////////////////////")
        response[0].destroy()
        .then(response=>{
        res.redirect('/get-blog')
        // res.redirect(req.get('referer'));

        })
        .catch(err=>{
            res.json({error:err})
        })
    })
}