const Sequelize=require('sequelize');
const sequelize=require('../util/databse');
const blog=sequelize.define('Blog',{
    id:{
        type:Sequelize.INTEGER,
        primaryKey:true,
        allowNull:false,
        autoIncrement:true,


    },
    blogName:{
        type:Sequelize.STRING,
        allowNull:false,
    },
    author:{
        type:Sequelize.STRING,
        allowNull:false
    },
    content:{
        type:Sequelize.TEXT,
        allowNull:false,
    }
})

module.exports=blog;