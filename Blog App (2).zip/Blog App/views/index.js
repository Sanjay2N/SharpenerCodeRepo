
const myform=document.querySelector("#myform");
const blogList=document.querySelector(".blogList");



myform.addEventListener("submit",addBlog);
window.addEventListener("DOMContentLoaded",reloadBlog);

function addComment(e){
    e.preventDefault();
    console.log("e.target :",e.target.commentContent.value)

    const comment=e.target.commentContent.value;
    const id=e.target.classList[1];
    console.log("id :",e.target.classList[1])
    const parent=document.querySelector('.commentList-'+id);
    console.log("parent is ",parent);
    axios.post("http://localhost:2000/post-comment",{comment:comment,id:id})
    .then(response=>{
            
            const li=document.createElement('li');
            li.classList="comment-"+response.data.id+"-"+response.data.BlogId +" "+response.data.id +" "+response.data.BlogId;
            const commentpara=document.createElement('p');
            // console.log("comment content is : ",response.data)
            commentpara.appendChild(document.createTextNode(response.data.content));
            li.appendChild(commentpara);
            const delbutton=document.createElement('button');
            delbutton.appendChild(document.createTextNode("X"));
            delbutton.classList="btn btn-outline-danger btn-sm delete-"+response.data.id+" "+response.data.id;
            
            li.appendChild(delbutton);
            parent.appendChild(li);
            document.querySelector(".delete-"+response.data.id).addEventListener('click',deleteComment);
            // console.log(".commentForm-"+id);
            // console.log(document.querySelector(".commentForm-"+id))
            document.querySelector(".commentForm-"+id).reset();

    })
}

function reloadBlog(e){
    e.preventDefault();
    axios.get("http://localhost:2000/get-blog")
    .then(response=>{
        response.data.forEach(blog=>{
            showOnDisplay(blog);
        })
    })
}



function addBlog(e){
    e.preventDefault();

    const name=e.target.name.value;
    const author=e.target.author.value;
    const content=e.target.content.value;
    const id=e.target.id.value;

    // console.log(name);
    // console.log("")
    // console.log(author);
    // console.log("")
    // console.log(content)
    myobj={
        id:id,
        name:name,
        author:author,
        content:content,
    }
    
    axios.post("http://localhost:2000/post-blog",myobj)
    .then(response=>{
        showOnDisplay(response.data);
    })
}

function deleteComment(e){
    const id=e.target.classList[4];
    // console.log("IDIDIDIIDIDIDIDIDIIDIDIDIDIDIDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDIIIIIIIIIIIIIIIIIIIIIIIIii")
    // console.log(e.target.classList)
    const li=e.target.parentElement;
        const commentList=e.target.parentElement.parentElement;
        console.log("remove is :",li)
        console.log("parent is : ",commentList)
        commentList.removeChild(li);
    axios.post("http://localhost:2000/delete-comment",{id:id})
   
}

function maximize(e){
    console.log("taregt ",e.target.parentElement)
    const minblog=e.target.parentElement;
    const blog=document.querySelector('.blog-'+e.target.classList[4]);
    minblog.style.display='none';
    blog.style.display='block';

}

function minimize(e){
    console.log("taregt ",e.target.classList)
    const blog=e.target.parentElement;
    const minblog=document.querySelector('.minblog-'+e.target.classList[3]);
    minblog.style.display='block';
    blog.style.display='none';

}



function showOnDisplay(response){

    //minimized tableLay
    const minDiv=document.createElement('div');
    minDiv.className="container minBlog-"+response.id;
    

    
    const minheader=document.createElement('h2');
    minheader.appendChild(document.createTextNode(response.blogName));
    minheader.style.display='inline';
    minheader.style.marginRight='10px';
    minDiv.appendChild(minheader);
    const minauthor=document.createElement('p');
    minauthor.appendChild(document.createTextNode(response.author));
    minauthor.style.display='inline';
    minDiv.appendChild(minauthor);
    
    minDiv.style.border="2px solid #7ef542 ";
    minDiv.style.borderRadius='5px';
    minDiv.style.marginBottom='4px';
    const maxbutton=document.createElement('button');
    maxbutton.appendChild(document.createElement('h4').appendChild(document.createTextNode("+")))

    maxbutton.classList='btn btn-info  btn-sm maxbutton-'+response.id+" "+response.id;
    
    maxbutton.style.float='right';
    
    minDiv.appendChild(maxbutton);

    blogList.appendChild(minDiv);
    console.log("class namwe"+'maxbutton-'+response.id)
    console.log(document.querySelector('maxbutton-'+response.id))
    document.querySelector('.maxbutton-'+response.id).addEventListener('click',maximize);



/////////////////////

    
    var div=document.createElement('div');
    div.className="container blog-"+response.id;
    // console.log(response.blogName)
    div.style.display='none';
    
    var h2=document.createElement('h2');
    h2.appendChild(document.createTextNode(response.blogName));
    h2.style.display='inline';
    const minbutton=document.createElement('button');
    minbutton.classList='btn btn-outline-success minbutton-'+response.id+" "+response.id;
    minbutton.appendChild(document.createElement('h4').appendChild(document.createTextNode("-")))
    minbutton.style.float='right';
    div.appendChild(minbutton);
    minbutton.addEventListener('click',minimize);
    // document.querySelector('.minbutton-'+response.id).addEventListener('click',minimize);

    div.appendChild(h2);
    var p=document.createElement('p');
    p.appendChild(document.createTextNode(`author : ${response.author}`))
    div.appendChild(p);
    div.appendChild(document.createElement('hr'));
    var h6=document.createElement('p');
    h6.appendChild(document.createTextNode(response.content));
    div.appendChild(h6);
    // div.appendChild('br');
    const commentheader=document.createElement('h5');
    commentheader.appendChild(document.createTextNode("Comment"))
    div.appendChild(commentheader);
    var commentdiv=document.createElement('div');
    commentdiv.classList=" commenttab form-group";

    const form=document.createElement('form');
    form.classList="commentForm-"+response.id +" "+response.id;

    const comment=document.createElement('input');
    comment.classList="form-control col-10 content-"+response.id;
    comment.type="text";
    comment.id="commentContent";
    const send=document.createElement('button');
    send.appendChild(document.createTextNode("post"));
    send.type='submit';
    send.classList="input-group-button btn btn-primary";
    comment.style.display='inline-block';
    form.appendChild(comment);
    
    form.appendChild(send);
    commentdiv.appendChild(form);
    div.appendChild(commentdiv)
    
    div.style.border="#7d34eb 2px solid";
    const commentList=document.createElement('ul');
    commentList.classList="commentList-"+response.id;
    console.log("class name  ",commentList.className)
    div.style.marginBottom="5px"

    blogList.appendChild(div);
    axios.get("http://localhost:2000/get-comments/"+response.id)
    .then(response=>{
        // console.log("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAa");
        // console.log("comment are :",response.data);
        response.data.forEach(comment=>{
        // console.log("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAa");
        //     console.log(comment.content)
            const li=document.createElement('li');
            li.classList="comment "+comment.id+" "+comment.BlogId;
            const commentpara=document.createElement('p');
            commentpara.appendChild(document.createTextNode(comment.content));
            commentpara.style.display='inline';
            commentpara.style.fontSize='20px'
            
            li.appendChild(commentpara);
            const delbutton=document.createElement('button');
            delbutton.appendChild(document.createTextNode("X"));
            delbutton.classList="btn btn-outline-danger btn-sm delete-"+comment.id+" "+comment.id;
            delbutton.style.float='right';
            delbutton.style.fontSize='10px';
            li.appendChild(delbutton);

            commentList.appendChild(li);
            // console.log(response)
           
            delEvnList=document.querySelector(".delete-"+comment.id);
            // console.log(delEvnList)
            delEvnList.addEventListener('click',deleteComment);

        })
    })
    const commentsend=document.querySelector(".commentForm-"+response.id);
    // console.log("commentsend :",commentsend)
    commentsend.addEventListener("submit",addComment);
    div.appendChild(commentList)
    myform.reset();
    


}