const express=require('express');

const Blog=require('./models/blog');

const Comment=require("./models/comment");

const cors=require('cors');

const routes=require('./routes/router');

const path=require('path');

const bodyparser=require('body-parser');

const sequelize=require('./util/databse');

const app=express();

app.use(cors());

app.use(bodyparser.urlencoded({extended:false}));

app.use(bodyparser.json({express:false}));

app.use(routes);

Blog.hasMany(Comment,{ constraints: true, onDelete: 'CASCADE' });
Comment.belongsTo(Blog,{ constraints: true, onDelete: 'CASCADE' });

sequelize
// .sync({force:true})
.sync()
.then(result=>{
    app.listen(2000);
})
.catch(err=>{
    console.log(err);
})