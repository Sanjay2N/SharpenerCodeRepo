const form=document.querySelector(".form");
form.addEventListener("submit",sendResponse);
function sendResponse(e){
    e.preventDefault();
    console.log(e.target)
    e.target.reset()
}