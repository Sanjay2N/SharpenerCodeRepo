const {Sequelize}=require('sequelize');

const sequelize=new Sequelize('expenses','root','Sanjay123@',{dialect:'mysql',host:'localhost'});

module.exports=sequelize;