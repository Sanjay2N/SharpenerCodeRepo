const { response } = require("express");
const Expenses=require("../models/expense");
const { connected } = require("process");

exports.postExpense=(req,res,next)=>{
    console.log("id is :",req.body.id)
    const Amount=req.body.amount;
    const For=req.body.for;
    const Category=req.body.category;
    const Id=req.body.id;
    if(Id==-1){
    
    Expenses.create({
        amount:Amount,
        for:For,
        category:Category,
    })
    .then(response=>{
        res.json(response)
    })
    .catch(err=>{
        res.json({error:err});
    })
    }
    else{
        Expenses.findByPk(Id)
        .then(response=>{
            response.amount=Amount;
            response.for=For;
            response.category=Category;
            response.save();
            res.json(response)
        })
        
        .catch(err=>{
            res.json({error:err});
        })
    }
}

exports.deleteExpense=(req,res,next)=>{
    Expenses.findByPk(req.body.id)
    .then(expense=>{
        expense.destroy();
        res.redirect('/get-expense')
    })
    .catch(err=>{
        res.json({error:err})
    })
}


exports.getExpense=(req,res,next)=>{
    Expenses.findAll()
    .then(response=>{
        // console.log("////////////////////////////////////////////////////")
        // console.log(response.da)
        res.json(response);
    })
}

exports.editExpense=(req,res,next)=>{
    const id=req.params.expId;
    // console.log("id is :",id)
    Expenses.findByPk(id)
    .then(response=>{
        // console.log("response is ....",response.dataValues.id)
        res.json(response.dataValues);
    })
    .catch(err=>{
        res.json({error:err});
    })
}