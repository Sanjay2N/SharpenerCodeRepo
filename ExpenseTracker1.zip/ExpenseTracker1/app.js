const express=require('express');

const cors=require('cors');

const path=require('path');

const bodyparser=require('body-parser');

const app=express();

const Expenses=require('./models/expense');

const sequelize=require('./util/database');

const routes=require('./routes/router');

app.use(cors());

// app.set('view engine','ejs');
// app.set('views','views');

app.use(bodyparser.urlencoded({extended:false}));

app.use(bodyparser.json({express:false}));

// app.use(express.static( path.join(__dirname,'public')));

app.use(routes);

sequelize
.sync()
// .sync({force:true})
.then(result=>{
    app.listen(5000)

})
.catch(err=>{
    console.log(err);
})