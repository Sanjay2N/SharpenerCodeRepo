
const myform=document.querySelector("#my-form");
const list=document.querySelector(".list");
const Amount=document.querySelector("#amount");
const For=document.querySelector("#For");
const Category=document.querySelector("#category");
const Id=document.querySelector("#id");




list.addEventListener("click",removeItem);

list.addEventListener("click",editItem);
myform.addEventListener("submit",addItem);

window.addEventListener("DOMContentLoaded",reloadItem);

function reloadItem(e){
    e.preventDefault();

    axios.get("http://localhost:5000/get-expense")
    .then(response=>{
        // console.log("<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>")
        // console.log(response.data)
        response.data.forEach(element => {
            showDataOnScreen(element)
        });
    })
}

function addItem(e){
    e.preventDefault();
    
    // console.log("for value",For.value);
    let myobj={
        id:Id.value,
        amount:Amount.value,
        for:For.value,
        category:Category.value
    };
    console.log("myobject ",myobj);
    
    axios.post("http://localhost:5000/post-expense",myobj)
    .then(response=>{
        // console.log("[[[[[[[[[[[[[[[[[[[[[]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]")
        // console.log(response.data)
        showDataOnScreen(response.data);
    })
    .catch(err=>{
        console.log(err)
    })

}

function removeItem(e){ 
    if(e.target.classList.contains('delete')){
        if(confirm("are you sure")){
            var li=e.target.parentElement;
            // console.log(li.classList[4])
            axios.post("http://localhost:5000/delete-expense",{id:li.classList[4]})
            .then(response=>{
                list.removeChild(li);
                localStorage.removeItem(li.classList[4]);
            })
            

        }
    }
}

function editItem(e){ 
    if(e.target.classList.contains('edit')){
           e.preventDefault();
            var li=e.target.parentElement;
            // console.log(li);
            myform.reset();
            // console.log(li.classList[4])
            axios.get("http://localhost:5000/edit-expense/"+li.classList[4])
            .then(response=>{
                console.log("edit response is :",response)
                document.querySelector("#amount").value=response.data.amount;

                document.querySelector("#for").value=response.data.for;

                document.querySelector("#category").value=response.data.category;
                document.querySelector("#id").value=response.data.id;


                // console.log(document.querySelector("#category").value)
                list.removeChild(li);
            })
            .catch(err=>{
                console.log(err);
            })
            
        
    }
}



function showDataOnScreen(myobj){
    var li=document.createElement('li');
    li.className="list-group-item d-flex justify-content-between align-items-center "+myobj.id;
    li.appendChild(document.createTextNode(myobj.amount+"  -  " +myobj.for+"  -  "+myobj.category));
    var delbutton=document.createElement('button');
    delbutton.className="btn btn-danger btn-sm float-right delete";
    delbutton.appendChild(document.createTextNode("X"));
    li.appendChild(delbutton);
    const edit=document.createElement("button");
    edit.appendChild(document.createTextNode("Edit"));
    edit.className="btn btn-danger btn-sm float-right edit";
    li.appendChild(edit);
    console.log(li);
    list.appendChild(li);
    myform.reset();


}