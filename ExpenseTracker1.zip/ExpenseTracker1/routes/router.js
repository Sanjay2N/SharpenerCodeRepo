const express=require('express');

const router=express.Router();

const path=require('path');

const controller=require('../controllers/controller');

router.post('/post-expense',controller.postExpense);

router.get('/get-expense',controller.getExpense);


router.post('/delete-expense',controller.deleteExpense);

router.get('/edit-expense/:expId',controller.editExpense);


module.exports=router;