const express=require('express');
const router=express.Router();
const expenseController=require("../controllers/expense");
const userAuthenticate=require("../middleware/auth");

router.post("/addexpense",userAuthenticate.authenticate,expenseController.addUserExpense);
router.get("/getexpense",userAuthenticate.authenticate,expenseController.getUserExpenses);
router.delete("/deleteexpense/:expenseId",userAuthenticate.authenticate,expenseController.deleteExpense);

module.exports=router;