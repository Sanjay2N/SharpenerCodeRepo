const express=require("express");
const cors=require("cors");
const body_parser=require("body-parser");
const signupRoutes=require("./routes/signup");
const loginRoutes=require("./routes/login");
const expenseRoutes=require("./routes/expense");
const User=require('./models/user');
const Expense=require('./models/expense');

const sequelize=require('./util/database')

const app=new express();

app.use(cors());
app.use(body_parser.json({express:false}));
app.use("/user",signupRoutes);
app.use("/user",loginRoutes);
app.use("/expense",expenseRoutes);
Expense.belongsTo(User);
User.hasMany(Expense, {
    foreignKey: 'userId'
  })

sequelize
// .sync({force:true})
.sync()
.then(result=>{
    app.listen(2000);
})
.catch(err=>{
    console.log(err);
})

