const User=require("../models/user");
const bcrypt=require('bcrypt');
const jwt=require('jsonwebtoken');

function getAccessToken(id){
    return jwt.sign({userId:id},"09884848493929292");
}

exports.userLogin=async (req,res,next)=>{
    try{

    
    const email=req.body.email;
    const password=req.body.password;
    if(email=="" || password==""){
        res.status(400).json();
        return;
    }
    const userDetails = await User.findAll({where:{email:email}});
    if(userDetails.length==0){
        res.status(404).json();
        return;
    }
    console.log("password  :",password);
    bcrypt.compare(password,userDetails[0].dataValues.password,(err,response)=>{
        console.log("error ",err)
        console.log("response :",response)
            if(err || response==false){
                res.status(401).json(err);
            }
            
            else{
                

                res.status(200).json({token:getAccessToken(userDetails[0].dataValues.id)});
                
            }
        })
    
    
}
catch{
    
        res.status(500).json({error:err});
    
}

}