const Expense=require("../models/expense");

function isStringNotValidate(string){
    if(string==undefined || string.length==0){
        return true;
    }
    return false;
}

exports.addUserExpense=async (req,res,next)=>{
    try{
        
        const {amount,date,category,description}=req.body;
        console.log(req.body)
        if(isStringNotValidate(amount) || isStringNotValidate(date) || isStringNotValidate(category) || isStringNotValidate(description)){
            res.status(400).json({message:"some thing missing"});
            return
            
        }
        const reponse=await Expense.create({
            userId:req.user.id,
            amount:amount,
            date:date,
            category:category,
            description:description
        })

        
        // const response=await req.user.createExpenses({
            
        //     amount:amount,
        //     date:date,
        //     category:category,
        //     description:description
        // })

        res.status(201).json(reponse);
        return;

    }
    catch(error){
        res.status(500).json({error:error});
    }
}


exports.getUserExpenses=async(req,res,next)=>{
    try{
        
        // const expenses=await Expense.findAll({where:{userId:req.user.dataValues.id}})
        
        const expenses=await req.user.getExpenses();

        res.status(200).json(expenses);
        
    }
    catch(error){
        res.status(500).json({error:error})
    }
}


exports.deleteExpense=async(req,res,next)=>{
    try{
    const id=req.params.expenseId;
    if(id==undefined || id.length===0){
        res.status(400).json();
        return;
    }
    await Expense.destroy({where:{id:id,userId:req.user.id}});
    // await req.user.deleteExpense();
  
    res.status(200).json();

    }
    catch(error){
        res.status(500).json();
    }

}