const num1Element=document.getElementById("num1") as HTMLInputElement;
const num2Element=document.getElementById("num2") as HTMLInputElement;
const buttonElement=document.querySelector("button")! ;

const numResult:Array<number>=[];
const textResult:string[]=[];

type numOrString=number|string;

function add(n1:numOrString,n2:numOrString){
    if(typeof n1==="string" && typeof n2==="string"){
        return n1+" "+n2;

    }
    if(typeof n1==="number" && typeof n2==="number"){
        return n1+n2;
    }

    return +n1 + +n2;
}

// type objStruct={val:number;timestamp:Date};

interface objStruct{val:number;timestamp:Date}

function printObject(obj:objStruct){
    console.log(obj.val);
}

buttonElement.addEventListener('click',()=>{
    const num1=num1Element.value;
    const num2=num2Element.value;
    const result=add(+num1,+num2);
    console.log(result);
    numResult.push(result as number);
    const resultString=add(num1,num2);
    console.log(resultString);
    textResult.push(resultString as string);
    printObject({val:result as number,timestamp:new Date()})
    console.log(numResult,textResult);

})


const prom=new Promise<string>((resolve,reject)=>{
    setTimeout(()=>{
        resolve("its done");
    },1000);
})
prom.then(result=>{
    console.log(result.split(""))
})