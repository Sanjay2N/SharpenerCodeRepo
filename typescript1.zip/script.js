"use strict";
const num1Element = document.getElementById("num1");
const num2Element = document.getElementById("num2");
const buttonElement = document.querySelector("button");
const numResult = [];
const textResult = [];
function add(n1, n2) {
    if (typeof n1 === "string" && typeof n2 === "string") {
        return n1 + " " + n2;
    }
    if (typeof n1 === "number" && typeof n2 === "number") {
        return n1 + n2;
    }
    return +n1 + +n2;
}
function printObject(obj) {
    console.log(obj.val);
}
buttonElement.addEventListener('click', () => {
    const num1 = num1Element.value;
    const num2 = num2Element.value;
    const result = add(+num1, +num2);
    console.log(result);
    numResult.push(result);
    const resultString = add(num1, num2);
    console.log(resultString);
    textResult.push(resultString);
    printObject({ val: result, timestamp: new Date() });
    console.log(numResult, textResult);
});
const prom = new Promise((resolve, reject) => {
    setTimeout(() => {
        resolve("its done");
    }, 1000);
});
prom.then(result => {
    console.log(result.split(""));
});
