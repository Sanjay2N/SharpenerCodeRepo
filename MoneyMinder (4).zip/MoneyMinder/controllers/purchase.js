const User=require("../models/user");
const Razorpay=require('razorpay');
const Order=require("../models/order");

const jwt=require('jsonwebtoken');

function getAccessToken(id,isPremiumUser){
    return jwt.sign({userId:id,isPremiumUser:isPremiumUser},"09884848493929292");
}

exports.purchasePremiumMemborship=async (req,res)=>{
    try{
        console.log("after the razorpay ")
        console.log(process.env.RAZORPAY_KEY_ID)
        console.log(process.env.RAZORPAY_KEY_SECRETE)

        var rzp=new Razorpay({
            key_id:process.env.RAZORPAY_KEY_ID,
            key_secret:process.env.RAZORPAY_KEY_SECRETE,
        })
        // console.log(rzp)
        const amount=500;
        rzp.orders.create({"amount":amount,"currency":"INR"},async(err,order)=>{
            // console.log("error is :",err)
            if(err){
                // throw new Error(JSON.stringify(err));
                return res.status(401).json({error:err})

            }
            console.log("after the order")
            const response=await req.user.createOrder({orderid:order.id,status:"PENDING"});
            return res.status(201).json({order,key_id:rzp.key_id});
        })
    }
    catch(error){
        console.log(error);
        return res.status(403).json({error:error});
    }
}

exports.updateTransactionStatus=async(req,res)=>{
    try{
        if(req.body.success==false){
            const order=await Order.findOne({where:{orderid:req.body.order_id}});
            await order.update({status:"FAILED"});
            return res.status(200).json({success:false,message:"transaction unsuccessful"});

        }
        console.log("////////////////////////////////////////////////////////////////////");
        console.log("inside of the update")
        const {payment_id,order_id}=req.body;
        const order=await Order.findOne({where:{orderid:order_id}});
        await order.update({paymentid:payment_id,status:"SUCCESSFUL"});
        await req.user.update({ispremiumuser:true});
        // await Promise.all([order.update({paymentid:payment_id,status:"SUCCESSFUL"}),req.user.update({ispremiumuser:true})]);
        res.status(200).json({success:true,message:"transaction successful",token:getAccessToken(req.user.id,req.user.ispremiumuser)});
        return;
        
    }
    catch(error){
        return res.status(401).json({error:"something went wrong"})

    }
}