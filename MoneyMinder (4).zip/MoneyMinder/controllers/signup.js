const User=require("../models/user");
const bcrypt=require('bcrypt');

exports.userSignup=(req,res,next)=>{
    
    try{
    const name=req.body.name;
    const email=req.body.email;
    const phoneNumber=req.body.phoneNumber;
    const password=req.body.password;
    console.log("............................: ",name)
    if(name=="" || email=="" || phoneNumber=="" || password==""){
        res.status(400).json({error:"Bad parameter"})
        return;
    }
    const saltrounds=10;
   bcrypt.hash(password,saltrounds,async(err,hash)=>{
    User.create({
        name:name,
        email:email,
        phoneNumber:phoneNumber,
        password:hash
    })
    .then(response=>{
        res.status(201).json(response);
    })
    .catch(err=>{
        res.status(401).json({error:err});
    })
    
   })

   
    
}
catch{
    res.status(500).json({error:err});
}


}