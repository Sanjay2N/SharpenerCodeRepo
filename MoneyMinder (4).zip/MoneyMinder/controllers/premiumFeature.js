const { Sequelize } = require("sequelize");
const Expense=require("../models/expense");
const User=require("../models/user");
const sequelize = require("../util/database");


exports.getLeaderBoard=async(req,res)=>{
    

    try{
        const response = await User.findAll({ 
            attributes: [ "name",[Sequelize.fn('sum',sequelize.col("expenses.amount")),"total_expense"]], 
            include: [ 
                { 
                    model: Expense, 
                    attributes: [], 
                    
                }, 
                
            ], 
            group:['user.id'],
            
            order:[['total_expense','DESC']],
            // where: {
            //     'total_expense': { [Op.gt]: 0 },
            //   },
            
        }); 
        // console.log(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::")
        // console.log(result);
        res.status(200).json(response);
    }
    catch(error){
        res.status(500).json({error:error});
    }

}

