const form=document.querySelector("#signup-form");
const warnig=document.querySelector("#warning");

console.log(document)

form.addEventListener("submit",signUp);


async function signUp(e){
    try{

    e.preventDefault();
    const name=e.target.name.value;
    const email=e.target.email.value;
    const phoneNUmber=e.target.number.value;
    const password=e.target.password.value;
    const conformPassword=e.target.conformationPassword.value;

    if(password!==conformPassword){
        warnig.innerText="Password not matching !!";
        form.querySelector("#password").value="";
        form.querySelector("#conformationPassword").value="";
        return;
    }

    userDetails={
        name:name,
        phoneNumber:phoneNUmber,
        email:email,
        password:password

    };
   

    
    const response=await axios.post("http://localhost:2000/user/signup",userDetails)
    const userCredentials=await axios.post("http://localhost:2000/user/signin",{email:userDetails.email,password:userDetails.password});
    console.log(userCredentials)
    userId=userCredentials.data.id;
    window.location.href="../HTML/expense.html";
    // localStorage.setItem('token', JSON.stringify({name:userDetails.Name,token:userCredentials.userDetails.token}));
    // window.location.href = `user`;     

    }
catch(error){
    if (error.response && error.response.status === 401) {
        e.preventDefault();
        console.log("Authentication failed. User is already exist.");
        warnig.innerText="Authentication failed. User is already exist.";
    }else if(error.response && error.response.status === 400){
        e.preventDefault();
        console.log("Bad inputs");
        warnig.innerText="Bad inputs,Some thing is missing";
        return;
    } 
    else {
        console.error("An error occurred:", error);
    }
    e.target.reset();
}
}