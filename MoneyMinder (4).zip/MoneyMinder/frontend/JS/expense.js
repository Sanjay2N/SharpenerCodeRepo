
const form=document.querySelector("#form");
const expenseBody=document.querySelector("#expense-body");


document.getElementById("date").value = new Date().toJSON().slice(0,10)

form.addEventListener("submit",addExpense);

async function addExpense(e){
    try{
        console.log("date  : ",e.target.date.value)
        e.preventDefault();
        console.log("same  kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk")
        const amount=e.target.amount.value;
        const date=e.target.date.value;
        const category=e.target.category.value;
        const description=e.target.description.value;
        expenseDetails={
            
            amount:amount,
            date:date,
            category:category,
            description:description,
            
        }
        // return
        console.log(expenseDetails)
        const token=localStorage.getItem("token");
        const response=await axios.post("http://localhost:2000/expense/addexpense",expenseDetails,{headers:{"Authorization":token}});
        if(response.status==201){
            // console.log(new Date().getDate());
            e.target.reset();
            showExpense(response.data);
           
            return;

        }
    }
    catch(error){
        if(error.response.status==400){
           
            document.querySelector("#warning").innerText=error.response.data.message;
        }
        else{
            console.log("error  : ")
            console.log(error)
        }
        
    }
}

function showExpense(expenseDetails){
    const id="expense-"+expenseDetails.id;
    expenseBody.innerHTML+=`
    <tr id=${id}>
                    <!-- <th scope="row">1</th> -->
                    <td>${expenseDetails.date}</td>
                    <td>${expenseDetails.amount}</td>
                    <td>${expenseDetails.category}</td>
                    <td><button class='btn btn-danger ${expenseDetails.id} '  onclick='deleteExpense(event,${expenseDetails.id})' id="delete-${expenseDetails.id}" >delete</button></td>

                    
                  </tr>`
               
}



async function deleteExpense(e,id){
    try{
        e.preventDefault();
        const token=localStorage.getItem("token");
        console.log("token  ",token);
        const response=await axios.delete("http://localhost:2000/expense/deleteexpense/"+id,{headers:{"Authorization":token}});
        document.querySelector("#expense-"+id).remove();

    }
    catch(error){
        if(error.response.data.status===400){
            console.log(error);
        }
    }
    
}


window.addEventListener("DOMContentLoaded",getExpense);

async function getExpense(){
    try{
        const token=localStorage.getItem("token");
        console.log("toke is :",token);
        console.log("in the js expensee file")
        const expenses=await axios.get(`http://localhost:2000/expense/getexpense`,{headers:{"Authorization":token}});
        console.log(expenses)
    expenses.data.forEach(expense=>{
        showExpense(expense);
    })
    }
    catch(error){
        console.log("error...........................................");
        console.log(error)
    }
    
}