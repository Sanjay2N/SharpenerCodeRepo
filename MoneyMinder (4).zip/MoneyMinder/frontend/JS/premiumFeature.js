const leaderBoardButton=document.querySelector("#leader-board-button");
const leaderBoardDiv=document.querySelector("#leader-board-div");
const leaderBoardList=document.querySelector("#leader-board");


function parseJwt(token) {
    var base64Url = token.split('.')[1];
    var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    var jsonPayload = decodeURIComponent(window.atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));

    return JSON.parse(jsonPayload);
}

const decodedToken=parseJwt(localStorage.getItem("token"));
console.log(decodedToken);

if(decodedToken.isPremiumUser===true){
    document.querySelector("#rzp-button1").classList.add("d-none")
    leaderBoardButton.classList.remove("d-none");

    leaderBoardButton.addEventListener("click",getLeaderBoard);

    async function getLeaderBoard(){
        leaderBoardButton.classList.add("d-none");
        const token=localStorage.getItem("token");
        const response=await axios.get("http://localhost:2000/premium/showleaderboard",{headers:{"Authorization":token}});
        console.log("response  ",response);
        response.data.forEach(expenseDetails=>{
            addToLeaderBoard(expenseDetails);
        })
        leaderBoardDiv.classList.remove("d-none");
        leaderBoardDiv.classList.add("d-flex");


    }


    function addToLeaderBoard(expenseDetails){
        leaderBoardDiv.innerHTML+=`<li class="list-group-item">${expenseDetails.name} -  ${expenseDetails.total_expense}INR</li>`;
    }
}
