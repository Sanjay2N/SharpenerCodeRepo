const express=require('express');
const router=express.Router();
const premiumFeatureController=require("../controllers/premiumFeature");
const userAuthenticate=require("../middleware/auth");

router.get("/showleaderboard",userAuthenticate.authenticate,premiumFeatureController.getLeaderBoard);


module.exports=router;