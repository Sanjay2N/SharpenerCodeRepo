const jwt=require('jsonwebtoken');
const User=require('../models/user');

exports.authenticate=async (req,res,next)=>{
    try{
        // console.log(req.header('Authorization'))
        console.log("inside of the auth")
        
        const token=req.header('Authorization');
        // console(req.header)
        // console.log("token>>>>",token);
        const user=jwt.verify(token,"09884848493929292");
        // console.log("user id>>>>>>>>>",user.userId);
        const reponse=await User.findByPk(user.userId);
        // console.log("response>>>>>>>>>>>",JSON.stringify(reponse));
        req.user=reponse;
        console.log("after response");
        next();
    }
    catch{
        return res.status(401).json({error:"user not found"});
    }
}