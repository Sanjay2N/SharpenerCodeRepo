const sequelize=require("../util/database");
const Sequelize=require("sequelize");

const DownloadedExpense=sequelize.define("downloadedexpense",{
    id:{
        type:Sequelize.INTEGER,
        allowNull:false,
        primaryKey:true,
        autoIncrement:true,
    },
    
    fileurl:{
        type:Sequelize.STRING,
        allowNull:false,

    },
    
    
})


module.exports=DownloadedExpense;