const { response } = require("express");
const Expense=require("../models/expense");
const sequelize=require("../util/database");
const Userservices=require("../services/userservices");
const { useInflection } = require("sequelize");

function isStringNotValidate(string){
    if(string==undefined || string.length==0){
        return true;
    }
    return false;
}

exports.addUserExpense=async (req,res,next)=>{
    const t= await sequelize.transaction();

    try{
        const {amount,date,category,description}=req.body;
        if(isStringNotValidate(amount) || isStringNotValidate(date) || isStringNotValidate(category) || isStringNotValidate(description)){
            return res.status(400).json({message:"some thing missing"});
        }

        const totalExpense=req.user.totalexpense+parseInt(amount);
        await req.user.update({totalexpense:totalExpense},{transaction:t});

        const response=await req.user.createExpense({
            amount:amount,
            date:date,
            category:category,
            description:description
        },{transaction:t});
        await t.commit();
        return res.status(201).json(response);

    }
    catch(error){
        await t.rollback();
        res.status(500).json({error:error});
    }
}


exports.getUserExpenses=async(req,res,next)=>{
    try{
        
        const expenses=await Userservices.getExpenses(req);

        res.status(200).json(expenses);
        
    }
    catch(error){
        res.status(500).json({error:error})
    }
}


exports.deleteUserExpense=async(req,res,next)=>{
    const t=await sequelize.transaction();
    try{

        const id=req.params.expenseId;
        if(id==undefined || id.length===0){
            return res.status(400).json();
        }
        const expense=await Expense.findOne({where:{id:id,userId:req.user.id}},{transaction:t});
        if(expense.length===0){
            return res.json(404).json({success:false});
        }
        
        const updatedTotalExpense=req.user.totalexpense-parseInt(expense.dataValues.amount);
        await Promise.all([req.user.update({totalexpense:updatedTotalExpense},{transaction:t}),expense.destroy({transaction:t})])
        await t.commit();
        res.status(200).json();

    }
    catch(error){
        await t.rollback();
        res.status(500).json({error:error});
    }

}