const { Sequelize, DATEONLY } = require("sequelize");
const Expense=require("../models/expense");
const User=require("../models/user");
const sequelize = require("../util/database");
const S3services=require("../services/s3services");
const DownloadExpense=require("../models/downloadedExpense");

exports.getLeaderBoard=async(req,res)=>{
    

    try{
        const response=await User.findAll({
            attributes: [ "name","totalexpense"],
            order:[['totalexpense','DESC']],
        });
        
        res.status(200).json(response);
    }
    catch(error){
        res.status(500).json({error:error});
    }

}


exports.downloadExpenses=async(req,res)=>{
    try{

        const userId=req.user.id;
        const expenses=await req.user.getExpenses();
        const stringifiedExpenses=JSON.stringify(expenses);
        const filename=`expenses${userId}/${new Date()}.txt`;
        const fileURL=await S3services.uploadToS3(stringifiedExpenses,filename);
      
        console.log("returning the respnse//////////////////////")
        console.log(fileURL)
        await DownloadExpense.create({fileurl:fileURL,userId:req.user.id});
        // await req.user.createdownloadedexpenses({fileurl:fileURL});
        console.log("after adding to table")
        res.status(200).json({fileURL:fileURL,successful:true});
    }
    catch(error){
        res.status(500).json({fileURL:'',success:false,error:error});
    }

}