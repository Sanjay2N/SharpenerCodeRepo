const leaderBoardButton=document.querySelector("#leader-board-button");
const leaderBoardDiv=document.querySelector("#leader-board-div");
const leaderBoardList=document.querySelector("#leader-board-body");

const token=localStorage.getItem("token");

function parseJwt(token) {
    var base64Url = token.split('.')[1];
    var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    var jsonPayload = decodeURIComponent(window.atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));

    return JSON.parse(jsonPayload);
}

const decodedToken=parseJwt(localStorage.getItem("token"));
console.log(decodedToken);

if(decodedToken.isPremiumUser===true){
    

    leaderBoardButton.addEventListener("click",getLeaderBoard);

    async function getLeaderBoard(){
        leaderBoardButton.classList.add("d-none");
        const response=await axios.get("http://localhost:2000/premium/showleaderboard",{headers:{"Authorization":token}});
        response.data.forEach(expenseDetails=>{
            addToLeaderBoard(expenseDetails);
        })
        leaderBoardDiv.classList.remove("d-none");
        leaderBoardDiv.classList.add("d-block");


    }
}


    function addToLeaderBoard(expenseDetails){
        if(expenseDetails.totalexpense==null){
            return;
        }
        leaderBoardList.innerHTML+=`
                <tr >
                        <td>${expenseDetails.name}</td>
                        <td>${expenseDetails.totalexpense}</td>
                        
                        
                        
                      </tr>`
}



document.querySelector("#expense-download-button").addEventListener("click",download);
async function download(event){
    try{
        console.log("inside of the download");
        event.preventDefault();

        const response=await axios.get('http://localhost:2000/premium/downloadexpenses', { headers: {"Authorization" : token} });
        console.log(response.data)
        if(response.status === 200){
           
            var a = document.createElement("a");
            a.href = response.data.fileURL;
            a.download = 'myexpense.csv';
            a.click();
    
    }
    }
    catch(error){
        console.log(error);
    }
}