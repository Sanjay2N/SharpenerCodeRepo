const form=document.querySelector("#forget-password-form");
const warning=document.querySelector("#warning");

form.addEventListener("submit",resetPassword);

async function resetPassword(e){
    try{
        e.preventDefault();
        console.log(e.target.email.value);
    const response=await axios.post("http://localhost:2000/password/forgotpassword",{email:e.target.email.value});
    
    }
    catch(error){
        warning.innerText="something went wrong";
        
    }

}