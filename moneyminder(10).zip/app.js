require('dotenv').config();

const express=require("express");
const cors=require("cors");
const body_parser=require("body-parser");
const signupRoutes=require("./routes/signup");
const loginRoutes=require("./routes/login");
const expenseRoutes=require("./routes/expense");
const purchaseRoutes=require("./routes/purchase");
const forgetPasswordRoutes=require("./routes/forgetPassword");
const premiumFeatureRoutes=require("./routes/premiumFeature");

const User=require('./models/user');
const Expense=require('./models/expense');
const Order=require("./models/order");
const ForgotPasswordRequest=require("./models/ForgotPasswordRequests");
const DownloadedExpense=require("./models/downloadedExpense");


const sequelize=require('./util/database')

const app=new express();

app.use(cors());
app.use(body_parser.json({express:false}));
app.use("/user",signupRoutes);
app.use("/user",loginRoutes);
app.use("/expense",expenseRoutes);
app.use("/purchase",purchaseRoutes);
app.use("/premium",premiumFeatureRoutes);
app.use("/password",forgetPasswordRoutes);
Expense.belongsTo(User);
User.hasMany(Expense, {
    foreignKey: 'userId'
  })

Order.belongsTo(User);
User.hasMany(Order, {
    foreignKey: 'userId'
})

ForgotPasswordRequest.belongsTo(User);
User.hasMany(ForgotPasswordRequest, {
    foreignKey: 'userId'
});

DownloadedExpense.belongsTo(User);
User.hasMany(DownloadedExpense, {
    foreignKey: 'userId'
});

sequelize
// .sync({force:true})
.sync()
.then(result=>{
    app.listen(2000);
})
.catch(err=>{
    console.log(err);
})

