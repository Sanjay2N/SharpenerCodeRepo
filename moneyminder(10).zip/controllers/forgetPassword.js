const User=require("../models/user");
const ForgotPasswordRequest=require("../models/ForgotPasswordRequests");

const bcrypt=require('bcrypt');
const Sib=require('sib-api-v3-sdk');
require('dotenv').config()

exports.forgetPassword=async (req,res)=>{
    try{
        console.log(req.body.email)
        const userDetails=await User.findOne({where:{email:req.body.email}});
        if(userDetails.length===0){
            return res.status(401).json({error:"no matching email exists"});
        }
        const client=Sib.ApiClient.instance;
        const apiKey=client.authentications['api-key'];
        apiKey.apiKey=process.env.FORGET_PASSWORD_API
        const tranEmailApi=new Sib.TransactionalEmailsApi();
        const sender={
            email:'sanjaykcbcs@gmail.com',
            name:"sanjay",

        };
        const receivers=[{
            email:req.body.email,
        }];
        const response=await ForgotPasswordRequest.create({
            userId:userDetails.id,
            isactive:true,
        });
        console.log(response.id);
        tranEmailApi.sendTransacEmail({
            sender:sender,
            to:receivers,
            subject:"MoneyMinder Password Reset",
            htmlContent:`
            <p>click here to reset password</p>
            <a href="http://localhost:2000/password/resetpassword/${response.id}"><h4>Reset Password</h4></a>
            `,
            params:{role:'Frontend'}
        }).then(response=>{
            console.log(response)
        })
        

        return res.status(200).json();


        

    }
    catch(error){
        // console.log("error ",error);
        return res.status(500).json({error:error});
    }
}

exports.resetPassword=async (req,res)=>{
    try{
        console.log("inside ot he reset")
        const id=req.params.requestId;
        const requestDetails=await ForgotPasswordRequest.findOne({where:{id:id}});
        if(requestDetails.isactive===false){
           return res.status(400).json();
        }
        console.log("[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]")
        await requestDetails.update({ isactive: false});
        res.status(200).send(`<html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Reset Password</title>
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous"> <title>Sign Up</title>
        
        </head>
        <body>
            <div class="  bg-dark d-flex " style="width: 100%;height: 100%;">
                <div   class="d-block bg-info  text-center m-auto rounded d-flex justify-content-center"  style="width: 30%;" >
                    <div  class="d-block bg-info w-75" >
                        <h2 class="text-light mt-4 mb-3" id="header">Reset Password</h2>
                        <form action="/password/updatepassword/${id}",  method="get" >
                            
                                <input type="password" id="email" name="newpassword" class="form-control mt-3" required placeholder="Enter Password">
                           
                            
                            <button type="submit" class="bg-gradient bg-success border-0 mt-3" id="button">Reset</button>
                        </form>
                        
                        <p id="warning" class="d-flex text-danger justify-content-center"></p>
        
                    </div>
                </div>
            </div>
          </div>
        
        </body>
        </html>`
                            )
        res.end()

    


    }
    catch(error){
        console.log(error)
    }

}

exports.updatePassword=async(req,res)=>{
    try {
        console.log("req",req)
        const { newpassword } = req.query;
        console.log("new password",newpassword);
        const  id= req.params.requestId;
        const requestDetails=await ForgotPasswordRequest.findOne({ where : { id:id }});
        
        const userDetails=await User.findOne({where: { id : requestDetails.userId}});
        // console.log("user details",userDetails);
                if(userDetails) {
                    //encrypt the password

                    const saltrounds=10;
                    bcrypt.genSalt(saltrounds, function(err, salt) {
                        if(err){
                            console.log(err);
                            throw new Error(err);
                        }
                        bcrypt.hash(newpassword,salt,async(err,hash)=>{
                            console.log("user password updated//////////////////////////////")
                        await userDetails.update({password:hash});
                        return res.status(201).json({message:"password reset successful"})
                    });
                });
                }
                else{
                    return res.status(404).json({ error: 'No user Exists', success: false})
                }
                
    } 
    catch(error){
        return res.status(403).json({ error, success: false } )
    }
}
