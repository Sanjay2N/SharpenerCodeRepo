const User=require("../models/user");
const bcrypt=require('bcrypt');
const jwt=require('jsonwebtoken');

function getAccessToken(id,isPremiumUser){
    return jwt.sign({userId:id,isPremiumUser:isPremiumUser},"09884848493929292");
}
exports.userLogin=async (req,res,next)=>{
    try{

    
        const email=req.body.email;
        const password=req.body.password;
        if(email=="" || password==""){
            return res.status(400).json();
            
        }
        const response = await User.findOne({where:{email:email}});
        if(response.length==0){
            return res.status(404).json();
        }
        const userDetails=response.dataValues;
        
        bcrypt.compare(password,userDetails.password,(err,response)=>{
                if(err || response==false){
                    return res.status(401).json({error:err});
                }
                else{
                    res.status(200).json({token:getAccessToken(userDetails.id,userDetails.ispremiumuser),isPremiumUser:userDetails.ispremiumuser});
                }
            })
        
    
}
catch{
    
        res.status(500).json({error:err});
    
}

}