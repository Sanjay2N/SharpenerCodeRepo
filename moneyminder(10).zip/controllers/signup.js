const User=require("../models/user");
const bcrypt=require('bcrypt');

function isNotValidInput(string){
    if(string.lenth===0 || string==undefined){
        return true;
    }
    return false;
}

exports.userSignup=(req,res,next)=>{
    
    try{
        const name=req.body.name;
        const email=req.body.email;
        const phoneNumber=req.body.phoneNumber;
        const password=req.body.password;
        if(isNotValidInput(name) || isNotValidInput(email) || isNotValidInput(phoneNumber) || isNotValidInput(password)){
            return res.status(400).json({error:"Bad parameter"});
            
        }
        const saltrounds=10;
        bcrypt.hash(password,saltrounds,async(err,hash)=>{
        const response=await User.create({
            name:name,
            email:email,
            phoneNumber:phoneNumber,
            password:hash
        });

        
        return res.status(201).json(response);
        
    })
}
catch{
    res.status(500).json({error:err});
}


}