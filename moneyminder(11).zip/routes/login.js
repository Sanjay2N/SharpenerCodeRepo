const express=require('express');
const router=express.Router();
const signinController=require("../controllers/login");

router.post("/login",signinController.userLogin);
module.exports=router;