
const form=document.querySelector("#form");
const expenseBody=document.querySelector("#expense-body");


document.getElementById("date").value = new Date().toJSON().slice(0,10)

form.addEventListener("submit",addExpense);

async function addExpense(e){
    try{
        e.preventDefault();
        const amount=e.target.amount.value;
        const date=e.target.date.value;
        const category=e.target.category.value;
        const description=e.target.description.value;
        expenseDetails={
            
            amount:amount,
            date:date,
            category:category,
            description:description,
            
        }
        
        const token=localStorage.getItem("token");
        const response=await axios.post("http://localhost:2000/expense/addexpense",expenseDetails,{headers:{"Authorization":token}});
        if(response.status==201){
            e.target.reset();
            // showExpense(response.data);
            return;

        }
    }
    catch(error){
        if(error.response.status==400){
            document.querySelector("#warning").innerText=error.response.data.message;
        }
        else{
            console.log("error  : ")
            console.log(error)
        }
        
    }
}

function showExpense(expenses){
    expenseBody.innerHTML="";

    expenses.forEach(expense=>{
        const id="expense-"+expense.id;
    expenseBody.innerHTML+=`
    <tr id=${id}>
                    <!-- <th scope="row">1</th> -->
                    <td>${expense.date}</td>
                    <td>${expense.amount}</td>
                    <td>${expense.category}</td>
                    <td><button class='btn btn-danger ${expense.id} '  onclick='deleteExpense(event,${expense.id})' id="delete-${expense.id}" >delete</button></td>

                    
                  </tr>`
    })

    
               
}



async function deleteExpense(e,id){
    try{
        e.preventDefault();
        const token=localStorage.getItem("token");
        console.log("token  ",token);
        const response=await axios.delete("http://localhost:2000/expense/deleteexpense/"+id,{headers:{"Authorization":token}});
        document.querySelector("#expense-"+id).remove();

    }
    catch(error){
        if(error.response.status===400){
            console.log(error);
        }
    }
    
}

let expensesPerPage=5;
const expensePerPageInput=document.querySelector("#expenses-per-page");

expensePerPageInput.addEventListener("change",()=>{
    console.log("event triggered");
    expensesPerPage=expensePerPageInput.value;
    localStorage.setItem("expensesPerPage",expensePerPageInput.value);

})

window.addEventListener("DOMContentLoaded",getExpense);

const pagination=document.querySelector("#pagination");


async function getExpense(event,page){
    try{
        if(page==undefined){
            page=1;
        }
        const token=localStorage.getItem("token");
        const expensesPerPage=localStorage.getItem("expensesPerPage");
        console.log("toke is :",token);
        console.log("in the js expensee file")

        console.log("expenses per page",expensesPerPage)
        const response=await axios.get(`http://localhost:2000/expense/getexpense?page=${page}&noItems=${expensesPerPage}`,{headers:{"Authorization":token}});
        console.log(response.data.currentPage)
        showExpense(response.data.expenses);

        showPagination(response.data);
    }
    catch(error){
        console.log("error...........................................");
        console.log(error)
    }
    
}
function showPagination({currentPage,hasNextPage,nextPage,hasPreviousPage,previousPage,lastPage}){
    pagination.innerHTML='';
    
    if(hasPreviousPage){
        const prevButton=document.createElement('button');
        prevButton.innerHTML=previousPage;
        prevButton.addEventListener("click",()=>getExpense({},previousPage));
        pagination.append(prevButton);
        
    }
    const curButton=document.createElement('button');
    curButton.innerHTML=`<h3>${currentPage}</h3>`;
    curButton.addEventListener("click",()=>getExpense({},currentPage));
    pagination.append(curButton);
    if(hasNextPage){
        const nextButton=document.createElement('button');
        nextButton.innerHTML=nextPage;
        nextButton.addEventListener("click",()=>getExpense({},nextPage));
        pagination.append(nextButton);
    }
}